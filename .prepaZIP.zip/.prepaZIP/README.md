Editeur de Carte en ligne:

Lancer l'éditeur : "npm run dev" Depuis le repertoire "Editeur-De-Carte".
Si vous êtes ailleurs : "cd Editeur-De-Carte"  

Utilisation de l'éditeur de carte :

0) Choisissez les dimentions de votre carte
1) Créé un champ
2) choisisez si vous mettez une image ou un texte
     a) TEXT : Choississez la couleur et la taille de la police
     b) IMG : Importez votre img, choississez sa taille et son placement
3) Continuez comme ça jusqu'à la création final de votre carte
4) enregistrez votre carte en json dans un dossier local pour pouvoir la modifier plus tard
5) Exporter la en PNG ou en PDF. 
